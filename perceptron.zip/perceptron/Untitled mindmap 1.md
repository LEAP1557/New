---

mindmap-plugin: basic

---

# mindmap-plugin: basic

## Sub title