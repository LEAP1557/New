



calendar
日历--日记
周历--周记

链接
- 双链：文章  段落
- 双链预览 
- 汇总页目录


Task代办事项
memo  灵感 类似 flomo
Quick Explorer

模版

``


daily notes+ calendar
1.  **[list|table|task]**： **Dataview** 有三种类型视图，列表，表格，任务，其中filed1，field字段等字段就是视图表头。
2.  **from** ：数据的来源，可以是文件夹，标签，链接。
3.  **where**： 筛选条件，支持field [>|>=|<|<=|=|&|'|'] [field2|literal value] (and field2 ...) (or field3...)这么多。
4.  **sort**：排序，按照某个关键字排序，有升序和降序，分别是为asc和desc。

具体例子吧
```text
list 
from ""
where contains(file.name,"每日反思")
sort file.ctime asc
```



dataview