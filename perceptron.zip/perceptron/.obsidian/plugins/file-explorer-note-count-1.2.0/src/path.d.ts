declare module 'path-browserify' {
    import path from 'path';
    export = path;
}
